package Homework51;
import java.util.Arrays;
import java.util.Scanner;

public class TrainTest {
	static String num = "G7029";
	public static void main(String[] args) {
		System.out.println(num + "次列车途经以下站点：");
		String[] cities = {"镇江","丹阳","常州","无锡","苏州","上海"};
		System.out.println(Arrays.toString(cities));
		System.out.println("请输入您要查询的站点名称：");
		Scanner s = new Scanner(System.in);
		String city = s.next();
		if (city.equals("镇江")) {
			Station zj = new ZhenJiang();
			zj.ticket();
		} else if (city.equals("丹阳")) {
			Station dy = new DanYang();
			dy.ticket();
		}else if (city.equals("常州")) {
			Station cz = new ChangZhou();
			cz.ticket();
		}else if (city.equals("无锡")) {
			Station wx = new WuXi();
			wx.ticket();
		}else if (city.equals("苏州")) {
			Station sz = new SuZhou();
			sz.ticket();
		}else if (city.equals("上海")) {
			Station sh = new ShangHai();
			sh.ticket();
		}else {
			System.out.println("Null");
		}
	}
}