package Homework51;

public class Station {
	protected String city;
	protected double price1;
	protected double price2;
	
	public double getPrice() {
		return price1;
	}

	public void setPrice(double price) {
		this.price1 = price;
	}

	public double getPrice2() {
		return price2;
	}

	public void setPrice2(double price2) {
		this.price2 = price2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Station() {
		
	}

	public Station(String city) {
		this.city = city;
	}
	
	public void ticket() {
		
	}
}

class ZhenJiang extends Station{
	public void ticket() {
		price1 = 44.5;
		price2 = 29.5;
		System.out.println("一等座：" + price1 +"元");
		System.out.println("二等座：" + price2 +"元");
	}
}

class DanYang extends Station{
	public void ticket() {
		price1 = 64.5;
		price2 = 39.5;
		System.out.println("一等座：" + price1 +"元");
		System.out.println("二等座：" + price2 +"元");
	}
}

class ChangZhou extends Station{
	public void ticket() {
		price1 = 99.5;
		price2 = 64.5;
		System.out.println("一等座：" + price1 +"元");
		System.out.println("二等座：" + price2 +"元");
	}
}

class WuXi extends Station{
	public void ticket() {
		price1 = 129.5;
		price2 = 79.5;
		System.out.println("一等座：" + price1 +"元");
		System.out.println("二等座：" + price2 +"元");
	}
}

class SuZhou extends Station{
	public void ticket() {
		price1 = 159.5;
		price2 = 99.5;
		System.out.println("一等座：" + price1 +"元");
		System.out.println("二等座：" + price2 +"元");
	}
}

class ShangHai extends Station{
	public void ticket() {
		price1 = 219.5;
		price2 = 139.5;
		System.out.println("一等座：" + price1 +"元");
		System.out.println("二等座：" + price2 +"元");
	}
}