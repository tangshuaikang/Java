package Homework51;

public class CarTest{
	public static void main(String[] args) {
		Car c = new Car("兰博基尼","Aventador",681.9,16.9,100,85);
		c.carInformation();//获取汽车信息
		c.cuel();//获取剩余油量
	}
}

class Car {
	private String brand;//品牌
	private String model;//车型
	private double price;//价格
	private double fuelConsumption;//油耗
	private double kilometer;//里程数
	private int tankVolume;//油箱容积
	private int remainingFuel;//剩余油量
	
	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getFuelConsumption() {
		return fuelConsumption;
	}

	public void setFuelConsumption(double fuelConsumption) {
		this.fuelConsumption = fuelConsumption;
	}

	public double getKilometer() {
		return kilometer;
	}

	public void setKilometer(double kilometer) {
		if (kilometer > (tankVolume/fuelConsumption)*100) {
			System.out.println("超出最大行驶距离");
		}
		this.kilometer = kilometer;
	}

	public int getTankVolume() {
		return tankVolume;
	}

	public void setTankVolume(int tankVolume) {
		this.tankVolume = tankVolume;
	}

	public double getRemainingFuel() {
		return remainingFuel;
	}

	public void setRemainingFuel(int remainingFuel) {
		this.remainingFuel = remainingFuel;
	}
	
	public Car() {
		
	}
	
	public Car(String brand, String model, double price, double fuelConsumption, double kilometer, int tankVolume) {
		this.brand = brand;
		this.model = model;
		this.price = price;
		this.fuelConsumption = fuelConsumption;
		this.kilometer = kilometer;
		this.tankVolume = tankVolume;
	}

	public void carInformation() {
		System.out.println("品牌：" + brand + "\n车型：" + model +"\n价格/万元：" + price + "\n油耗/L：" + fuelConsumption
				+ "\n里程数/km：" + kilometer + "\n油箱容积/L：" + tankVolume);
	}
	
	public void cuel() {
		//消耗的油量
		double consumption = ( kilometer / 100 ) * fuelConsumption;
		//剩余油量
		remainingFuel = (int) (tankVolume-consumption);
		System.out.println("剩余油量：" + remainingFuel);
	}
}
